package data;

import org.apache.commons.codec.language.*;

public class StandardizeName {

	public static String encode(String s){
		DoubleMetaphone meta = new DoubleMetaphone();
		//Soundex soundex = new Soundex();
		return meta.encode(s);
			
	}
}
		
		

		
	
		
		
