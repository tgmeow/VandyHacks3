package controller;

/**
 * @author tgmeow
 *	The different positions for the controller. So far only TOP and TOP RIGHT have been completed and tested.
 */
public enum ControllerPosition {
	TOP, TOP_RIGHT//,TOP_LEFT, RIGHT, LEFT, BOTTOM, BOTTOM_LEFT, BOTTOM_RIGHT
}
